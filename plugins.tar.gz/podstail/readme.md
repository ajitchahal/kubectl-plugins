Tails logs of all pods.
 Examples
    $ kubectl plugin mtail app=web,tier=frontend
    $ kubectl plugin mtail app=web,tier=frontend -n my-namespace my-container